import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "motion/react";
import CustomCursor from "./components/CustomCursor";
import HeroSection from "./components/HeroSection";
import AboutSection from "./components/AboutSection";
import IncludedSection from "./components/IncludedSection";
import ContactSection from "./components/ContactSection";
import Footer from "./components/Footer";
import Logo from "./components/Logo";

export default function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Elegant loading duration
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2200);
    return () => clearTimeout(timer);
  }, []);

  const handleScrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <>
      {/* Custom Interactivity Cursor */}
      <CustomCursor />

      <AnimatePresence mode="wait">
        {loading ? (
          /* CINEMATIC ZEN ENTRY LOADER */
          <motion.div
            key="loader"
            className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-mist-black text-mountain-cream select-none"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, y: -40 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          >
            {/* Subtle rotating circular lines */}
            <div className="relative w-24 h-24 flex items-center justify-center mb-8">
              <motion.div
                className="absolute inset-0 rounded-full border border-lime-accent/20"
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              />
              <motion.div
                className="absolute w-16 h-16 rounded-full border border-t-lime-accent border-r-transparent border-b-transparent border-l-transparent"
                animate={{ rotate: -360 }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              />
              <motion.div
                className="w-12 h-12 flex items-center justify-center"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <Logo size={40} />
              </motion.div>
            </div>

            {/* Cinematic Zen typography */}
            <div className="space-y-4 text-center px-6">
              <motion.span
                className="font-mono text-xs uppercase tracking-[0.4em] text-lime-accent font-semibold block"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.3 }}
              >
                10-day curated travel
              </motion.span>
              <motion.h1
                className="font-serif text-3xl sm:text-4xl md:text-5xl font-light tracking-wide text-mountain-cream"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1.2, delay: 0.6 }}
              >
                Connect Japan
              </motion.h1>
              <motion.p
                className="font-mono text-[10px] text-mouse-gray tracking-[0.2em] uppercase max-w-xs mx-auto"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1, delay: 1 }}
              >
                Misty valleys, golden temples & neon alleyways
              </motion.p>
            </div>
          </motion.div>
        ) : (
          /* PRIMARY CINEMATIC LANDING PAGE CONTENT */
          <motion.main
            key="content"
            className="relative min-h-screen bg-mist-black"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            {/* Hero z-index Layered Composition */}
            <HeroSection onScrollToSection={handleScrollToSection} />

            {/* About the Tour Content Section */}
            <AboutSection />

            {/* Bento Grid Features Included Section */}
            <IncludedSection />

            {/* Cinematic Contact and Request Booking Section */}
            <ContactSection />

            {/* Elegant Global Footer */}
            <Footer onScrollToSection={handleScrollToSection} />
          </motion.main>
        )}
      </AnimatePresence>
    </>
  );
}
