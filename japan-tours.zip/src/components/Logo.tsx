import { SVGProps } from "react";

interface LogoProps extends SVGProps<SVGSVGElement> {
  size?: number;
  className?: string;
}

export default function Logo({ size = 32, className, ...props }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      {...props}
    >
      {/* Deep Rich Red Circle Background */}
      <circle cx="50" cy="50" r="44" fill="#C1121F" />
      
      {/* White Dashed Path Curve */}
      <path
        d="M 17 80 Q 42 76 58 54"
        stroke="white"
        strokeWidth="3"
        strokeDasharray="5 4"
        strokeLinecap="round"
      />
      
      {/* Under Fold (Grey-ish Keel/Shadow) */}
      <polygon
        points="58,54 62,51 58,47"
        fill="#B3B3B3"
      />

      {/* Main Left Wing (Pure White) */}
      <polygon
        points="90,10 47,34 58,54"
        fill="white"
      />

      {/* Shaded Right Wing (Light Grey for 3D depth) */}
      <polygon
        points="90,10 58,54 76,60"
        fill="#E5E5E5"
      />
    </svg>
  );
}
