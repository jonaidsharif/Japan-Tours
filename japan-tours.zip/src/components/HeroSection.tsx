import { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { Instagram, Facebook, Send } from "lucide-react";
import { PolaroidItem } from "../types";
import Logo from "./Logo";

// Import local assets
import mistyMountains from "../assets/images/misty_mountains_dawn_1782786507619.jpg";
import kimonoWoman from "../assets/images/kimono_woman_foreground_1782786523877.jpg";

interface HeroSectionProps {
  onScrollToSection: (sectionId: string) => void;
}

const polaroids: PolaroidItem[] = [
  {
    id: "1",
    image: "https://images.unsplash.com/photo-1545569341-9eb8b30979d9?auto=format&fit=crop&q=80&w=500",
    caption: "3 cities in Japan",
    title: "Kyoto Pagoda",
  },
  {
    id: "2",
    image: "https://images.unsplash.com/photo-1524413840807-0c3cb6fa808d?auto=format&fit=crop&q=80&w=500",
    caption: "10 days",
    title: "Misty Fields",
  },
  {
    id: "3",
    image: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&q=80&w=500",
    caption: "gigabytes of photos",
    title: "Red Shrine",
  },
  {
    id: "4",
    image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&q=80&w=500",
    caption: "eat ramen",
    title: "Ramen Haven",
  },
  {
    id: "5",
    image: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&q=80&w=500",
    caption: "enjoy the vibe",
    title: "Tokyo Neon",
  },
];

export default function HeroSection({ onScrollToSection }: HeroSectionProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Parallax scroll transforms
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const mountainsY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "35%"]);
  // Polaroid strip drift
  const polaroidX = useTransform(scrollYProgress, [0, 1], ["0%", "-15%"]);

  return (
    <div
      id="hero"
      ref={containerRef}
      className="relative w-full h-[105vh] md:h-[110vh] overflow-hidden bg-mist-black"
    >
      {/* BACKGROUND PLANE - Misty Mountains */}
      <motion.div
        className="absolute inset-0 w-full h-full scale-105 origin-bottom"
        style={{ y: mountainsY }}
      >
        <img
          src={mistyMountains}
          alt="Misty Japanese Mountains at Dawn"
          className="w-full h-full object-cover brightness-[0.95]"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-mist-black via-transparent to-black/30" />
      </motion.div>

      {/* MID-GROUND PLANE - Giant JAPAN outline text behind the mountain ridge */}
      <motion.div
        className="absolute inset-x-0 top-[22%] sm:top-[20%] md:top-[18%] flex justify-center items-center select-none pointer-events-none"
        style={{ y: textY }}
      >
        <h1 className="text-serif font-light text-[14vw] md:text-[18vw] tracking-[0.15em] text-outline-white text-center select-none leading-none w-full">
          JAPAN
        </h1>
      </motion.div>

      {/* FOREGROUND MOUNTAIN LAYER (CLIP PATH)
          To create the perfect z-index layering where 'JAPAN' is nested behind mountain ridges,
          we overlay the mountain image again with a custom polygon clip-path representing the ridges. */}
      <motion.div
        className="absolute inset-0 w-full h-full scale-105 pointer-events-none origin-bottom select-none"
        style={{
          y: mountainsY,
          clipPath: "polygon(0% 43%, 12% 38%, 25% 45%, 38% 34%, 52% 41%, 65% 36%, 78% 44%, 90% 36%, 100% 41%, 100% 100%, 0% 100%)",
        }}
      >
        <img
          src={mistyMountains}
          alt=""
          className="w-full h-full object-cover brightness-[0.95]"
          referrerPolicy="no-referrer"
        />
      </motion.div>

      {/* FOREGROUND PLANE - Solitary Kimono Woman on the right side & Cherry Blossom foliage */}
      <div className="absolute right-0 bottom-0 top-0 w-full md:w-1/2 pointer-events-none z-10 flex items-end justify-end">
        <motion.div
          className="relative w-[75%] md:w-[65%] h-[85%] md:h-[90%] flex items-end justify-end mr-[-5%] sm:mr-0"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        >
          <img
            src={kimonoWoman}
            alt="Kimono Woman overlooking misty valley"
            className="w-full h-[95%] object-contain select-none filter drop-shadow-[0_20px_50px_rgba(0,0,0,0.6)]"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </div>

      {/* FLOATING BOOK BUTTON (Next to Kimono Figure) */}
      <div className="absolute right-4 md:right-[22%] bottom-[25%] md:bottom-[28%] z-20">
        <motion.button
          onClick={() => onScrollToSection("contact")}
          className="interactive relative px-8 py-3.5 bg-mountain-cream/95 text-mist-black font-mono text-sm tracking-[0.2em] uppercase font-semibold overflow-hidden group shadow-[0_10px_30px_rgba(0,0,0,0.4)] transition-all duration-300 hover:text-mist-black rounded"
          whileHover={{ y: -4, scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
        >
          {/* Fills bottom-up with warm amber gradient on hover */}
          <div className="absolute inset-0 bg-gradient-to-t from-lime-accent to-[#E4C560] translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-[0.16,1,0.3,1] z-0" />
          <span className="relative z-10 flex items-center gap-2">
            Book <Send size={14} className="group-hover:translate-x-1 transition-transform" />
          </span>
        </motion.button>
      </div>

      {/* NAVIGATION HEADER (Z-Index 30 to hover above everything) */}
      <header className="absolute top-0 left-0 right-0 p-6 md:p-10 flex justify-between items-center z-30">
        {/* Left Side: Brand wordmark */}
        <div className="flex items-center gap-3 text-mountain-cream">
          <Logo size={32} className="animate-pulse" />
          <span className="font-mono text-sm tracking-[0.2em] uppercase font-bold">
            Connect Japan
          </span>
        </div>

        {/* Right Side Nav Links */}
        <nav className="hidden md:flex items-center gap-10">
          {["about", "included", "contact"].map((section) => (
            <button
              key={section}
              onClick={() => onScrollToSection(section)}
              className="interactive relative font-mono text-xs text-mountain-cream/80 uppercase tracking-[0.2em] hover:text-lime-accent transition-colors duration-300 py-1 group"
            >
              {section === "contact" ? "Contacts" : section}
              <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-lime-accent transition-all duration-300 group-hover:w-full" />
            </button>
          ))}
          <button
            onClick={() => onScrollToSection("contact")}
            className="interactive px-5 py-2 border border-mountain-cream/30 hover:border-lime-accent rounded-full font-mono text-xs text-mountain-cream uppercase tracking-[0.2em] transition-all duration-300 hover:bg-lime-accent/10"
          >
            Book
          </button>
        </nav>

        {/* Mobile menu toggle or quick Book */}
        <div className="flex md:hidden">
          <button
            onClick={() => onScrollToSection("contact")}
            className="interactive px-4 py-1.5 border border-mountain-cream/30 rounded-full font-mono text-xs text-mountain-cream uppercase tracking-[0.15em]"
          >
            Book
          </button>
        </div>
      </header>

      {/* RIGHT EDGE - Faint Outlined Social Links */}
      <div className="absolute right-6 md:right-10 top-1/3 flex flex-col gap-6 items-center z-30">
        <div className="w-[1px] h-10 bg-mountain-cream/20" />
        <a
          href="#"
          className="interactive text-mountain-cream/60 hover:text-lime-accent transition-colors duration-300 hover:scale-110"
          aria-label="Instagram"
        >
          <Instagram size={16} />
        </a>
        <a
          href="#"
          className="interactive text-mountain-cream/60 hover:text-lime-accent transition-colors duration-300 hover:scale-110"
          aria-label="Facebook"
        >
          <Facebook size={16} />
        </a>
        <a
          href="#"
          className="interactive text-mountain-cream/60 hover:text-lime-accent transition-colors duration-300 hover:scale-110"
          aria-label="Telegram"
        >
          <svg
            viewBox="0 0 24 24"
            width="16"
            height="16"
            stroke="currentColor"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21.13 2.82a2 2 0 0 0-2.31-.33L3.14 10.74a1 1 0 0 0-.12 1.83l5.52 2.22a1 1 0 0 0 .93-.05l7.14-5a.41.41 0 0 1 .59.56l-5.11 6.84a1 1 0 0 0 .15 1.34l4.63 3.9a1 1 0 0 0 1.55-.42l3.41-16.71a2 2 0 0 0-.15-1.47z" />
          </svg>
        </a>
        <div className="w-[1px] h-20 bg-mountain-cream/20" />
      </div>

      {/* FLOATING POLAROID CARDS (Lower-left third) with scroll horizontal drift */}
      <div className="absolute left-4 md:left-12 bottom-10 md:bottom-14 z-20 max-w-[90vw] md:max-w-[45vw] overflow-visible">
        <motion.div
          className="flex gap-4 md:gap-6"
          style={{ x: polaroidX }}
        >
          {polaroids.map((card, idx) => (
            <motion.div
              key={card.id}
              className="interactive flex-shrink-0 w-36 sm:w-44 bg-[#121212] p-2.5 rounded shadow-[0_15px_35px_rgba(0,0,0,0.5)] border border-white/5 relative overflow-hidden"
              whileHover={{
                y: -8,
                borderColor: "rgba(212, 248, 122, 0.4)",
                boxShadow: "0 25px 40px rgba(212, 248, 122, 0.08)",
              }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              {/* Image Container with subtle zoom on hover */}
              <div className="w-full h-44 sm:h-52 overflow-hidden rounded-sm relative group bg-black">
                <img
                  src={card.image}
                  alt={card.title}
                  className="w-full h-full object-cover transition-transform duration-700 ease-[0.16,1,0.3,1] group-hover:scale-110 group-hover:brightness-110 brightness-[0.85]"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              </div>

              {/* Polaroid bottom caption */}
              <div className="pt-3 pb-1">
                <p className="font-mono text-[9px] sm:text-[10px] uppercase text-mouse-gray tracking-wider leading-none">
                  {card.caption}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Decorative Sakura petals blowing (ambient Ghibli feeling) */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-3 bg-sakura-pink/40 rounded-full"
            style={{
              top: `${20 + i * 12}%`,
              left: `${-5 + i * 15}%`,
            }}
            animate={{
              x: ["0vw", "105vw"],
              y: ["0vh", "35vh"],
              rotate: [0, 360],
            }}
            transition={{
              duration: 15 + i * 4,
              repeat: Infinity,
              ease: "linear",
              delay: i * 2,
            }}
          />
        ))}
      </div>
    </div>
  );
}
