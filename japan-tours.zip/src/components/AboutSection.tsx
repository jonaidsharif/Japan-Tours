import { motion } from "motion/react";
import { TimelineItem } from "../types";

// Import local assets
import osakaCastle from "../assets/images/osaka_castle_cherry_blossoms_1782786554265.jpg";
import osakaMoatBoat from "../assets/images/osaka_moat_boat_1782788412048.jpg";
import kyotoPagoda from "../assets/images/kyoto_pagoda_misty_morning_1782786570442.jpg";
import kyotoTorii from "../assets/images/kyoto_torii_gates_1782788460796.jpg";
import tokyoStreet from "../assets/images/tokyo_narrow_street_lanterns_1782786585592.jpg";
import tokyoKabukicho from "../assets/images/tokyo_kabukicho_gate_1782788426126.jpg";

const timelineItems: TimelineItem[] = [
  {
    id: "osaka",
    days: "Days 1–3",
    city: "Osaka",
    photos: [
      osakaCastle,
      osakaMoatBoat,
    ],
    description: "Indulge in street food in Dotonbori, explore historic castle gardens, and absorb the bustling pulse of dynamic cityscapes.",
  },
  {
    id: "kyoto",
    days: "Days 4–6",
    city: "Kyoto",
    photos: [
      kyotoPagoda,
      kyotoTorii,
    ],
    description: "Step into silent stone temples, walk through towering bamboo groves, and observe the slow, graceful tea ceremonies at dawn.",
  },
  {
    id: "tokyo",
    days: "Days 7–10",
    city: "Tokyo",
    photos: [
      tokyoStreet,
      tokyoKabukicho,
    ],
    description: "Submerge in neon alleys, visit timeless shrines nestled under skyscrapers, and experience Shibuya's beautiful intersection of life.",
  },
];

export default function AboutSection() {
  return (
    <section
      id="about"
      className="relative bg-mist-black text-kimono-white py-24 md:py-36 overflow-hidden border-t border-white/5"
    >
      {/* SECTION HEADING WITH EXTENDING HAIRLINE RULES */}
      <div className="w-full flex items-center justify-center mb-20 md:mb-28 px-4">
        <div className="h-[1px] bg-white/10 flex-grow" />
        <motion.h2
          className="mx-6 font-display text-4xl sm:text-5xl md:text-6xl tracking-[0.25em] text-center font-bold uppercase text-mountain-cream"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          ABOUT THE TOUR
        </motion.h2>
        <div className="h-[1px] bg-white/10 flex-grow" />
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24">
        {/* LEFT COLUMN - Editorial Text */}
        <div className="lg:col-span-5 flex flex-col justify-start space-y-12 lg:sticky lg:top-32 h-fit">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-8"
          >
            {/* Paragraph 1 with scrolling highlight logic */}
            <p className="font-serif text-lg sm:text-xl md:text-2xl font-light text-mountain-cream/80 leading-relaxed">
              We've planned a simple and convenient 10-day itinerary for your trip to Japan. You'll visit three cities:{" "}
              <motion.span
                className="font-medium inline-block text-lime-accent"
                initial={{ color: "rgba(245, 232, 211, 0.8)" }}
                whileInView={{ color: "#D4F87A" }}
                viewport={{ once: false, amount: 0.8 }}
                transition={{ duration: 0.6 }}
              >
                Osaka, Kyoto, and Tokyo.
              </motion.span>
            </p>

            {/* Paragraph 2 with scrolling highlight logic */}
            <p className="font-serif text-lg sm:text-xl md:text-2xl font-light text-mountain-cream/80 leading-relaxed">
              No need to worry about routes, schedules, or finding places — everything is already organized. We'll show you where to go, what to see, and where to eat, so you can simply{" "}
              <motion.span
                className="font-medium inline-block text-lime-accent"
                initial={{ color: "rgba(245, 232, 211, 0.8)" }}
                whileInView={{ color: "#D4F87A" }}
                viewport={{ once: false, amount: 0.8 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                enjoy the journey.
              </motion.span>
            </p>
          </motion.div>

          {/* Premium Quote Callout */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 1 }}
            className="border-l-2 border-lime-accent/50 pl-6 py-2 space-y-2"
          >
            <span className="font-mono text-[10px] tracking-[0.2em] text-mouse-gray uppercase">
              Curated philosophy
            </span>
            <p className="text-sm italic text-mouse-gray leading-relaxed">
              "To travel is to encounter the silent spaces within ourselves, colored by the crimson of autumn leaves and neon glow."
            </p>
          </motion.div>
        </div>

        {/* RIGHT COLUMN - Vertical Interactive Offset Photo Timeline */}
        <div className="lg:col-span-7 relative pl-8 sm:pl-16">
          {/* Vertical Line running top-to-bottom */}
          <div className="absolute left-3 sm:left-[3.25rem] top-4 bottom-4 w-[1px] bg-white/10" />

          <div className="space-y-24 md:space-y-36">
            {timelineItems.map((item, index) => (
              <motion.div
                key={item.id}
                className="relative flex flex-col md:flex-row md:items-start gap-8 md:gap-12"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-120px" }}
                transition={{ duration: 0.8, delay: index * 0.15, ease: [0.16, 1, 0.3, 1] }}
              >
                {/* Timeline Node - outer glowing node */}
                <div className="absolute left-[-29px] sm:left-[-73px] top-1.5 flex items-center justify-center">
                  <div className="w-5 h-5 rounded-full border border-lime-accent bg-mist-black flex items-center justify-center shadow-[0_0_15px_rgba(212,248,122,0.3)]">
                    <motion.div
                      className="w-2.5 h-2.5 rounded-full bg-lime-accent"
                      initial={{ scale: 0.6 }}
                      whileInView={{ scale: [0.6, 1, 0.6] }}
                      viewport={{ once: false }}
                      transition={{ duration: 3, repeat: Infinity }}
                    />
                  </div>
                </div>

                {/* Content Area */}
                <div className="flex-1 space-y-4">
                  {/* Label: Days & City */}
                  <div>
                    <span className="font-mono text-xs text-lime-accent tracking-widest uppercase font-semibold">
                      {item.days}
                    </span>
                    <h3 className="font-serif text-3xl sm:text-4xl text-mountain-cream mt-1 font-normal">
                      {item.city}
                    </h3>
                  </div>

                  <p className="text-mouse-gray text-sm max-w-md leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Photo Scrapbook Cluster (Right-aligned in row, overlapping/rotated) */}
                <motion.div
                  className="interactive relative w-56 h-48 sm:w-64 sm:h-52 self-center md:self-start mt-4 cursor-pointer"
                  whileHover="hover"
                >
                  {/* Photo 1 (Behind, slightly rotated left) */}
                  <motion.div
                    className="absolute inset-0 bg-mist-black p-1.5 border border-white/10 rounded shadow-[0_10px_20px_rgba(0,0,0,0.4)] overflow-hidden"
                    style={{ rotate: -4, x: -10, y: -5 }}
                    variants={{
                      hover: {
                        rotate: -8,
                        x: -25,
                        y: -10,
                        borderColor: "rgba(212,248,122,0.3)",
                        scale: 1.05,
                      },
                    }}
                    transition={{ type: "spring", stiffness: 200, damping: 18 }}
                  >
                    <img
                      src={item.photos[0]}
                      alt={`${item.city} view 1`}
                      className="w-full h-full object-cover rounded-sm brightness-90"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>

                  {/* Photo 2 (Foreground, slightly rotated right) */}
                  <motion.div
                    className="absolute inset-x-8 inset-y-4 bg-mist-black p-1.5 border border-white/10 rounded shadow-[0_15px_30px_rgba(0,0,0,0.5)] overflow-hidden"
                    style={{ rotate: 3, x: 15, y: 15 }}
                    variants={{
                      hover: {
                        rotate: 7,
                        x: 35,
                        y: 25,
                        borderColor: "rgba(212,248,122,0.3)",
                        scale: 1.05,
                      },
                    }}
                    transition={{ type: "spring", stiffness: 200, damping: 18 }}
                  >
                    <img
                      src={item.photos[1]}
                      alt={`${item.city} view 2`}
                      className="w-full h-full object-cover rounded-sm brightness-[0.85]"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
