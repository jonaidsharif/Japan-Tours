import { ComponentType } from "react";
import { motion } from "motion/react";
import { Compass, Plane, Train, Hotel } from "lucide-react";
import { IncludedCard } from "../types";

const cards: IncludedCard[] = [
  {
    id: "guides",
    iconName: "Compass",
    title: "Guides",
    description: "2 awesome, bilingual local guides who know every hidden alley, local ramen bar, and ancient legend in Japan!",
  },
  {
    id: "flights",
    iconName: "Plane",
    title: "Flights",
    description: "Full booking assistance & premium flights. Travel comfort guaranteed: Moscow — Osaka, Tokyo — Moscow.",
  },
  {
    id: "transfers",
    iconName: "Train",
    title: "Transfers",
    description: "Fully organized private transfers from airports directly to hotels, plus premium Shinkansen bullet train passes.",
  },
  {
    id: "hotels",
    iconName: "Hotel",
    title: "Hotels",
    description: "Handpicked boutique boutique hotels, comfortable double occupancy, with gourmet traditional breakfasts included.",
  },
];

const iconMap: Record<string, ComponentType<{ className?: string; size?: number }>> = {
  Compass: Compass,
  Plane: Plane,
  Train: Train,
  Hotel: Hotel,
};

export default function IncludedSection() {
  return (
    <section
      id="included"
      className="relative bg-mist-black text-kimono-white py-24 md:py-36 overflow-hidden border-t border-white/5"
    >
      {/* Decorative ambient background glow */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 w-96 h-96 bg-lime-accent/5 rounded-full filter blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 w-[400px] h-[400px] bg-sakura-pink/5 rounded-full filter blur-[150px] pointer-events-none" />

      {/* SECTION HEADING */}
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center mb-16 md:mb-24">
        <motion.h2
          className="font-display text-4xl sm:text-5xl md:text-6xl tracking-[0.25em] font-bold uppercase text-mountain-cream whitespace-nowrap"
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          WHAT'S INCLUDED
        </motion.h2>
        <div className="h-[1px] bg-white/10 flex-grow ml-8" />
      </div>

      {/* BENTO GRID */}
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {cards.map((card, index) => {
            const IconComponent = iconMap[card.iconName];
            return (
              <motion.div
                key={card.id}
                className="interactive relative p-8 rounded-2xl bg-white/[0.02] border border-white/10 backdrop-blur-md overflow-hidden group flex flex-col justify-between min-h-[280px]"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{
                  y: -6,
                  borderColor: "rgba(212, 248, 122, 0.35)",
                  boxShadow: "0 20px 40px rgba(212, 248, 122, 0.05)",
                }}
              >
                {/* Subtle Amber Glow behind card on hover */}
                <div className="absolute inset-0 bg-gradient-to-tr from-lime-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                {/* Top: Icon */}
                <div className="mb-8">
                  <div className="w-12 h-12 rounded-xl bg-white/[0.03] border border-white/5 flex items-center justify-center group-hover:bg-lime-accent/10 group-hover:border-lime-accent/30 transition-all duration-500">
                    {IconComponent && (
                      <motion.div
                        variants={{
                          hover: { scale: 1.15, rotate: 5 },
                        }}
                        transition={{ type: "spring", stiffness: 300, damping: 15 }}
                      >
                        <IconComponent className="text-lime-accent transition-transform duration-300" size={22} />
                      </motion.div>
                    )}
                  </div>
                </div>

                {/* Bottom Content */}
                <div className="space-y-4">
                  <h3 className="font-mono text-sm uppercase tracking-[0.25em] text-mountain-cream font-bold group-hover:text-lime-accent transition-colors duration-300">
                    {card.title}
                  </h3>
                  <p className="text-mouse-gray text-xs sm:text-sm leading-relaxed group-hover:text-kimono-white transition-colors duration-300">
                    {card.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
