import { Instagram, Facebook } from "lucide-react";
import Logo from "./Logo";

interface FooterProps {
  onScrollToSection: (sectionId: string) => void;
}

export default function Footer({ onScrollToSection }: FooterProps) {
  return (
    <footer className="bg-mist-black text-kimono-white py-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 md:px-12 space-y-10">
        {/* UPPER ROW: REPEATING NAV & LOGO */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand Wordmark */}
          <button
            onClick={() => onScrollToSection("hero")}
            className="interactive flex items-center gap-3 text-mountain-cream hover:text-lime-accent transition-colors duration-300"
          >
            <Logo size={28} />
            <span className="font-mono text-sm tracking-[0.25em] uppercase font-bold">
              Connect Japan
            </span>
          </button>

          {/* Navigation Links */}
          <nav className="flex flex-wrap items-center justify-center gap-8 sm:gap-10">
            <button
              onClick={() => onScrollToSection("hero")}
              className="interactive font-mono text-xs text-mountain-cream/70 uppercase tracking-[0.2em] hover:text-lime-accent transition-colors duration-300"
            >
              Home
            </button>
            <button
              onClick={() => onScrollToSection("about")}
              className="interactive font-mono text-xs text-mountain-cream/70 uppercase tracking-[0.2em] hover:text-lime-accent transition-colors duration-300"
            >
              About
            </button>
            <button
              onClick={() => onScrollToSection("included")}
              className="interactive font-mono text-xs text-mountain-cream/70 uppercase tracking-[0.2em] hover:text-lime-accent transition-colors duration-300"
            >
              Included
            </button>
            <button
              onClick={() => onScrollToSection("contact")}
              className="interactive font-mono text-xs text-mountain-cream/70 uppercase tracking-[0.2em] hover:text-lime-accent transition-colors duration-300"
            >
              Contacts
            </button>
          </nav>
        </div>

        {/* THIN HAIRLINE RULE ABOVE BOTTOM ROW */}
        <div className="h-[1px] bg-white/10 w-full" />

        {/* LOWER ROW: COPYRIGHT & SOCIAL ICONS */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-mouse-gray text-[10px] sm:text-xs font-mono tracking-widest uppercase">
          <span>&copy; {new Date().getFullYear()} Connect Japan. All rights reserved.</span>

          {/* Social Links (Faint Outlined Icons) */}
          <div className="flex items-center gap-6">
            <a
              href="#"
              className="interactive text-mountain-cream/40 hover:text-lime-accent transition-colors duration-300 hover:scale-110"
              aria-label="Instagram"
            >
              <Instagram size={16} />
            </a>
            <a
              href="#"
              className="interactive text-mountain-cream/40 hover:text-lime-accent transition-colors duration-300 hover:scale-110"
              aria-label="Facebook"
            >
              <Facebook size={16} />
            </a>
            <a
              href="#"
              className="interactive text-mountain-cream/40 hover:text-lime-accent transition-colors duration-300 hover:scale-110"
              aria-label="Telegram"
            >
              <svg
                viewBox="0 0 24 24"
                width="16"
                height="16"
                stroke="currentColor"
                strokeWidth="2"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21.13 2.82a2 2 0 0 0-2.31-.33L3.14 10.74a1 1 0 0 0-.12 1.83l5.52 2.22a1 1 0 0 0 .93-.05l7.14-5a.41.41 0 0 1 .59.56l-5.11 6.84a1 1 0 0 0 .15 1.34l4.63 3.9a1 1 0 0 0 1.55-.42l3.41-16.71a2 2 0 0 0-.15-1.47z" />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
