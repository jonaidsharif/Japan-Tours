import { useState, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Globe, Send, CheckCircle } from "lucide-react";

// Import local assets
import fujiBackground from "../assets/images/mt_fuji_pagoda_cherry_blossoms_1782786539143.jpg";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    comment: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
      alert("Please provide both your name and phone number so we can reach you.");
      return;
    }
    
    setIsSubmitting(true);
    // Simulate API request
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setFormData({ name: "", phone: "", comment: "" });
    }, 1500);
  };

  return (
    <section
      id="contact"
      className="relative w-full min-h-[90vh] md:min-h-screen flex items-center justify-start py-20 px-6 md:px-12 overflow-hidden bg-mist-black"
    >
      {/* BACKGROUND IMAGE - Mt Fuji & Pagoda with Cherry Blossoms */}
      <div className="absolute inset-0 w-full h-full">
        <img
          src={fujiBackground}
          alt="Mount Fuji with Pagoda and Cherry Blossoms"
          className="w-full h-full object-cover brightness-[0.75]"
          referrerPolicy="no-referrer"
        />
        {/* Soft sunrise overlay gradients */}
        <div className="absolute inset-0 bg-gradient-to-r from-mist-black/95 via-mist-black/60 to-transparent md:block hidden" />
        <div className="absolute inset-0 bg-gradient-to-t from-mist-black via-transparent to-transparent md:hidden block" />
      </div>

      {/* FOREGROUND CONTENT CONTAINER */}
      <div className="relative z-10 w-full max-w-7xl mx-auto flex">
        {/* FROSTED GLASS FORM PANEL */}
        <motion.div
          className="w-full max-w-lg bg-[#141414]/50 border border-white/10 backdrop-blur-xl rounded-2xl p-8 sm:p-10 md:p-12 shadow-[0_25px_50px_rgba(0,0,0,0.6)] flex flex-col justify-center"
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        >
          <AnimatePresence mode="wait">
            {!isSuccess ? (
              <motion.form
                key="booking-form"
                onSubmit={handleSubmit}
                className="space-y-8"
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                {/* Headers */}
                <div className="space-y-4">
                  <span className="font-mono text-[10px] sm:text-xs text-lime-accent tracking-[0.3em] uppercase font-bold block">
                    Leave a request
                  </span>
                  <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl text-mountain-cream font-normal leading-tight">
                    Want to join us, but still have questions?
                  </h3>
                </div>

                {/* Fields */}
                <div className="space-y-6">
                  {/* Name Input */}
                  <div className="relative group">
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Your name"
                      className="w-full bg-transparent font-sans text-sm py-3 px-1 text-kimono-white border-b border-white/20 focus:border-lime-accent outline-none transition-colors duration-300 placeholder-white/30"
                    />
                    <div className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-lime-accent transition-all duration-300 group-focus-within:w-full" />
                  </div>

                  {/* Phone Input */}
                  <div className="relative group">
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="Phone number"
                      className="w-full bg-transparent font-sans text-sm py-3 px-1 text-kimono-white border-b border-white/20 focus:border-lime-accent outline-none transition-colors duration-300 placeholder-white/30"
                    />
                    <div className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-lime-accent transition-all duration-300 group-focus-within:w-full" />
                  </div>

                  {/* Comment Input */}
                  <div className="relative group">
                    <textarea
                      rows={3}
                      value={formData.comment}
                      onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                      placeholder="Comment"
                      className="w-full bg-transparent font-sans text-sm py-3 px-1 text-kimono-white border-b border-white/20 focus:border-lime-accent outline-none transition-colors duration-300 placeholder-white/30 resize-none"
                    />
                    <div className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-lime-accent transition-all duration-300 group-focus-within:w-full" />
                  </div>
                </div>

                {/* Submit Button */}
                <motion.button
                  type="submit"
                  disabled={isSubmitting}
                  className="interactive w-full py-4 bg-mountain-cream text-mist-black font-mono text-xs uppercase tracking-[0.25em] font-bold rounded-lg shadow-lg hover:bg-lime-accent transition-colors duration-300 flex items-center justify-center gap-2 cursor-pointer"
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <svg
                        className="animate-spin h-4 w-4 text-mist-black"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Sending Request...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      Send Request <Send size={12} />
                    </span>
                  )}
                </motion.button>
              </motion.form>
            ) : (
              <motion.div
                key="success-message"
                className="text-center py-12 space-y-6 flex flex-col items-center justify-center"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 25 }}
              >
                <div className="w-16 h-16 rounded-full bg-lime-accent/10 border border-lime-accent/40 flex items-center justify-center text-lime-accent mb-2">
                  <CheckCircle size={36} className="animate-bounce" />
                </div>
                <div className="space-y-3">
                  <h4 className="font-serif text-2xl text-mountain-cream">
                    Thank you!
                  </h4>
                  <p className="text-mouse-gray text-sm leading-relaxed max-w-xs mx-auto">
                    Your request has been received. Our team will contact you shortly to curate your perfect Japan journey.
                  </p>
                </div>
                <motion.button
                  onClick={() => setIsSuccess(false)}
                  className="interactive px-6 py-2 border border-mountain-cream/30 rounded-full font-mono text-[10px] uppercase text-mountain-cream tracking-widest hover:border-lime-accent hover:text-lime-accent transition-colors mt-4"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Send another request
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
