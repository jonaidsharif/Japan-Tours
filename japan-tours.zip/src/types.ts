export interface TimelineItem {
  id: string;
  days: string;
  city: string;
  photos: string[];
  description: string;
}

export interface PolaroidItem {
  id: string;
  image: string;
  caption: string;
  title: string;
}

export interface IncludedCard {
  id: string;
  iconName: string;
  title: string;
  description: string;
}
